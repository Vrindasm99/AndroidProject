package com.example.sql_masterclass;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class TopicAdapter extends ArrayAdapter<String> {

    Context context;
    String[] topics;

    public TopicAdapter(Context context, String[] topics) {
        super(context, R.layout.item_topic, topics);
        this.context = context;
        this.topics = topics;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_topic, parent, false);
        }

        String topicName = topics[position];

        TextView tvName = convertView.findViewById(R.id.tvTopicName);
        TextView tvPercent = convertView.findViewById(R.id.tvPercentage);

        tvName.setText(topicName);

        // Retrieve Progress
        SharedPreferences prefs = context.getSharedPreferences("SQL_PROGRESS", Context.MODE_PRIVATE);
        int progress = prefs.getInt(topicName, 0); // Default is 0

        tvPercent.setText(progress + "%");

        // Optional: Color code completion
        if (progress == 100) {
            tvPercent.setTextColor(android.graphics.Color.parseColor("#04AA6D")); // Green
        } else {
            tvPercent.setTextColor(android.graphics.Color.GRAY);
        }

        return convertView;
    }
}