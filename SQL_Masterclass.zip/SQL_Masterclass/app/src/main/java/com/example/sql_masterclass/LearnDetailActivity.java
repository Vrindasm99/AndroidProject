package com.example.sql_masterclass;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;

public class LearnDetailActivity extends AppCompatActivity {

    DrawerLayout drawerLayout;
    NavigationView navigationView;

    // UI Elements
    TextView tvTitle, tvIntro, tvExampleTables, tvCode, tvDescription;
    Button btnTryIt, btnMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learn_detail);

        // 1. Setup Drawer
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        btnMenu = findViewById(R.id.btnMenu);

        // 2. Link Text Views
        tvTitle = findViewById(R.id.tvTitle);
        tvIntro = findViewById(R.id.tvIntro);
        tvExampleTables = findViewById(R.id.tvExampleTables);
        tvCode = findViewById(R.id.tvCode);
        tvDescription = findViewById(R.id.tvDescription);
        btnTryIt = findViewById(R.id.btnTryIt);

        // 3. Get initial topic from Intent
        String initialTopic = getIntent().getStringExtra("TOPIC_NAME");
        if (initialTopic == null) initialTopic = "SELECT";

        loadTopicContent(initialTopic);

        // 4. Button to Open Sidebar
        btnMenu.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        // 5. Sidebar Item Click Listener
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                // Determine which topic was clicked
                String selectedTopic = item.getTitle().toString();

                // Load the new content
                loadTopicContent(selectedTopic);

                // Close the drawer
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });
    }

    private void loadTopicContent(String topic) {
        // Get data from our helper class
        LearnContent.Page pageData = LearnContent.getPage(topic);

        // Update UI
        tvTitle.setText(pageData.title);
        tvIntro.setText(pageData.intro);
        tvExampleTables.setText(pageData.exampleTable);
        tvCode.setText(pageData.code);
        tvDescription.setText(pageData.description);

        // Update Try It Button
        String codeToRun = pageData.code;
        btnTryIt.setOnClickListener(v -> {
            Intent intent = new Intent(LearnDetailActivity.this, PlaygroundActivity.class);
            intent.putExtra("PRE_FILLED_QUERY", codeToRun);
            startActivity(intent);
        });
    }
}