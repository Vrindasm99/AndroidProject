package com.example.sql_masterclass;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

public class PracticeListActivity extends AppCompatActivity {

    ListView listView;
    // List of topics available in the app
    String[] topics = {"SELECT", "WHERE", "ORDER BY", "INSERT", "UPDATE"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practice_list);

        listView = findViewById(R.id.listView);

        // Setup the list click listener
        listView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedTopic = topics[position];
            Intent intent = new Intent(PracticeListActivity.this, PracticeActivity.class);
            intent.putExtra("TOPIC_NAME", selectedTopic);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // This ensures the percentages update when you come back from a quiz
        updateList();
    }

    private void updateList() {
        // Use our custom adapter instead of the default one
        TopicAdapter adapter = new TopicAdapter(this, topics);
        listView.setAdapter(adapter);
    }
}