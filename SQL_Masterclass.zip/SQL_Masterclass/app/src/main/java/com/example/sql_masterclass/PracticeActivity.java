package com.example.sql_masterclass;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class PracticeActivity extends AppCompatActivity {

    // --- Helper Class ---
    static class Question {
        String type; // "MCQ" or "CODE"
        String text;
        String answer; // Correct SQL or Correct MCQ Option Text
        String[] options; // Only for MCQ

        // Constructor for Coding Question
        public Question(String text, String answer) {
            this.type = "CODE";
            this.text = text;
            this.answer = answer;
        }

        // Constructor for MCQ
        public Question(String text, String answer, String[] options) {
            this.type = "MCQ";
            this.text = text;
            this.answer = answer;
            this.options = options;
        }
    }

    // --- Variables ---
    DatabaseHelper dbHelper;
    SQLiteDatabase db;

    TextView tvTopicTitle, tvQuestion, tvResult, tvProgress;
    EditText etQuery;
    Button btnRun;
    LinearLayout layoutCoding;
    RadioGroup radioGroup;
    RadioButton rb1, rb2, rb3, rb4;
    ProgressBar progressBar;

    List<Question> questionList = new ArrayList<>();
    int currentQuestionIndex = 0;
    String currentTopic = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practice);

        currentTopic = getIntent().getStringExtra("TOPIC_NAME");
        if (currentTopic == null) currentTopic = "SELECT";

        // Link UI
        tvTopicTitle = findViewById(R.id.tvLevel);
        tvQuestion = findViewById(R.id.tvQuestion);
        tvResult = findViewById(R.id.tvResult);
        etQuery = findViewById(R.id.etQuery);
        btnRun = findViewById(R.id.btnRun);
        layoutCoding = findViewById(R.id.layoutCoding);
        radioGroup = findViewById(R.id.radioGroup);
        rb1 = findViewById(R.id.rbOption1);
        rb2 = findViewById(R.id.rbOption2);
        rb3 = findViewById(R.id.rbOption3);
        rb4 = findViewById(R.id.rbOption4);
        progressBar = findViewById(R.id.progressBar);
        tvProgress = findViewById(R.id.tvProgress);

        tvTopicTitle.setText("Topic: " + currentTopic);

        // Setup DB
        dbHelper = new DatabaseHelper(this);
        try {
            db = dbHelper.getReadableDatabase();
        } catch (Exception e) {
            e.printStackTrace();
        }

        loadQuestions(currentTopic);
        showQuestion();
    }

    private void loadQuestions(String topic) {
        questionList.clear();

        // ================= SELECT =================
        if (topic.equals("SELECT")) {
            questionList.add(new Question("What does SQL stand for?", "Structured Query Language",
                    new String[]{"Structured Query Language", "Strong Question Language", "Structured Question List", "Simple Query Logic"}));
            questionList.add(new Question("Write a query to select all columns from 'Customers'.",
                    "SELECT * FROM Customers;"));
            questionList.add(new Question("Which keyword selects data from a database?", "SELECT",
                    new String[]{"EXTRACT", "GET", "OPEN", "SELECT"}));
            questionList.add(new Question("Write a query to select the 'City' column from 'Customers'.",
                    "SELECT City FROM Customers;"));
            questionList.add(new Question("Which character selects ALL columns?", "*",
                    new String[]{"%", "*", "&", "ALL"}));
            questionList.add(new Question("Select 'CustomerName' and 'City' from 'Customers'.",
                    "SELECT CustomerName, City FROM Customers;"));
        }
        // ================= WHERE =================
        else if (topic.equals("WHERE")) {
            questionList.add(new Question("Which keyword is used to filter records?", "WHERE",
                    new String[]{"FILTER", "WHERE", "SEARCH", "WHEN"}));
            questionList.add(new Question("Select all customers from 'Mexico'.",
                    "SELECT * FROM Customers WHERE Country = 'Mexico';"));
            questionList.add(new Question("Which operator implies 'Not Equal'?", "<>",
                    new String[]{"<>", "><", "==", "!"}));
            questionList.add(new Question("Select customers where 'CustomerID' is 1.",
                    "SELECT * FROM Customers WHERE CustomerID = 1;"));
            questionList.add(new Question("True or False: SQL text strings need quotes.", "True",
                    new String[]{"True", "False", "Depends on DB", "None"}));
            questionList.add(new Question("Select products where Price is 18.",
                    "SELECT * FROM Products WHERE Price = 18;"));
        }
        // ================= ORDER BY =================
        else if (topic.equals("ORDER BY")) {
            questionList.add(new Question("Which keyword sorts the result-set?", "ORDER BY",
                    new String[]{"SORT BY", "ORDER BY", "ORGANIZE", "ALIGN"}));
            questionList.add(new Question("Select all customers ordered by Country.",
                    "SELECT * FROM Customers ORDER BY Country;"));
            questionList.add(new Question("By default, ORDER BY sorts in which direction?", "Ascending",
                    new String[]{"Ascending", "Descending", "Random", "None"}));
            questionList.add(new Question("Select customers ordered by City descending.",
                    "SELECT * FROM Customers ORDER BY City DESC;"));
            questionList.add(new Question("Which keyword sorts in descending order?", "DESC",
                    new String[]{"DESC", "DSC", "DOWN", "MINUS"}));
            questionList.add(new Question("Select products ordered by Price.",
                    "SELECT * FROM Products ORDER BY Price;"));
        }
        // ================= INSERT =================
        else if (topic.equals("INSERT")) {
            questionList.add(new Question("Which statement inserts new data?", "INSERT INTO",
                    new String[]{"ADD NEW", "INSERT INTO", "ADD RECORD", "UPDATE"}));
            questionList.add(new Question("Complete the syntax: INSERT ___ table_name...", "INTO",
                    new String[]{"INTO", "TO", "IN", "VALUES"}));
            questionList.add(new Question("Write a query to insert a new Category 'Sports' with Description 'Gear'. (Assuming ID is auto-handled)",
                    "INSERT INTO Categories (CategoryName, Description) VALUES ('Sports', 'Gear');"));
            questionList.add(new Question("Can you insert data into specific columns only?", "Yes",
                    new String[]{"Yes", "No", "Only in Oracle", "Only in MySQL"}));
            // Note: Simpler Coding question for mobile typing
            questionList.add(new Question("Insert a new Shipper named 'SpeedyExpress'.",
                    "INSERT INTO Shippers (ShipperName) VALUES ('SpeedyExpress');"));
            questionList.add(new Question("Which keyword precedes the data values?", "VALUES",
                    new String[]{"DATA", "SET", "VALUES", "INPUT"}));
        }
        // ================= UPDATE =================
        else if (topic.equals("UPDATE")) {
            questionList.add(new Question("Which statement modifies existing data?", "UPDATE",
                    new String[]{"SAVE", "MODIFY", "UPDATE", "CHANGE"}));
            questionList.add(new Question("Update 'Customers': Set ContactName to 'Alfred' where CustomerID is 1.",
                    "UPDATE Customers SET ContactName = 'Alfred' WHERE CustomerID = 1;"));
            questionList.add(new Question("What happens if you omit WHERE in UPDATE?", "All records update",
                    new String[]{"Nothing happens", "All records update", "Error occurs", "Only first row updates"}));
            questionList.add(new Question("Update 'Products': Set Price to 20 where ProductID is 1.",
                    "UPDATE Products SET Price = 20 WHERE ProductID = 1;"));
            questionList.add(new Question("Which keyword specifies the new value?", "SET",
                    new String[]{"to", "SET", "EQUALS", "VALUE"}));
            // Note: Coding safety check implies simple updates
            questionList.add(new Question("Update 'Shippers': Set Phone to '123' where ShipperID is 1.",
                    "UPDATE Shippers SET Phone = '123' WHERE ShipperID = 1;"));
        }
    }

    private void showQuestion() {
        int totalQuestions = questionList.size();

        progressBar.setMax(totalQuestions);
        progressBar.setProgress(currentQuestionIndex);
        tvProgress.setText("Question " + (currentQuestionIndex + 1) + " of " + totalQuestions);

        // --- CHECK COMPLETED ---
        if (currentQuestionIndex >= totalQuestions) {
            tvQuestion.setText("🎉 Topic Completed!");
            progressBar.setProgress(totalQuestions);
            tvProgress.setText("Completed!");

            // SAVE PROGRESS
            SharedPreferences prefs = getSharedPreferences("SQL_PROGRESS", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putInt(currentTopic, 100);
            editor.apply();

            layoutCoding.setVisibility(View.GONE);
            radioGroup.setVisibility(View.GONE);

            tvResult.setText("Great job! You finished all " + currentTopic + " exercises.");
            tvResult.setTextColor(Color.parseColor("#04AA6D"));

            btnRun.setText("BACK TO TOPICS");
            btnRun.setOnClickListener(v -> finish());
            return;
        }

        // --- SHOW QUESTION ---
        btnRun.setText("SUBMIT ANSWER");
        btnRun.setOnClickListener(v -> checkAnswer());

        Question q = questionList.get(currentQuestionIndex);
        tvQuestion.setText("Q" + (currentQuestionIndex + 1) + ": " + q.text);
        tvResult.setText("");

        if (q.type.equals("MCQ")) {
            layoutCoding.setVisibility(View.GONE);
            radioGroup.setVisibility(View.VISIBLE);
            radioGroup.clearCheck();
            rb1.setText(q.options[0]);
            rb2.setText(q.options[1]);
            rb3.setText(q.options[2]);
            rb4.setText(q.options[3]);
        } else {
            layoutCoding.setVisibility(View.VISIBLE);
            radioGroup.setVisibility(View.GONE);
            etQuery.setText(getSimpleStarterCode(currentTopic));
        }
    }

    // Helper to give a small hint in the text box
    private String getSimpleStarterCode(String topic) {
        if (topic.equals("INSERT")) return "INSERT INTO ";
        if (topic.equals("UPDATE")) return "UPDATE ";
        return "SELECT ";
    }

    private void checkAnswer() {
        Question q = questionList.get(currentQuestionIndex);

        if (q.type.equals("MCQ")) {
            int selectedId = radioGroup.getCheckedRadioButtonId();
            if (selectedId == -1) {
                Toast.makeText(this, "Please select an answer", Toast.LENGTH_SHORT).show();
                return;
            }
            RadioButton selectedRb = findViewById(selectedId);
            String userChoice = selectedRb.getText().toString();

            if (userChoice.equals(q.answer)) {
                showSuccess();
            } else {
                tvResult.setTextColor(Color.RED);
                tvResult.setText("❌ Wrong. Correct answer: " + q.answer);
            }
        }
        else {
            String userQuery = etQuery.getText().toString().trim();
            // Basic validation for coding
            if (userQuery.isEmpty()) {
                Toast.makeText(this, "Please write a query", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                // For INSERT/UPDATE we use different logic than SELECT
                if (q.text.toLowerCase().contains("insert") || q.text.toLowerCase().contains("update")) {
                    // For Practice purposes, we might just check string match to avoid breaking the DB permanently for the user
                    // OR we actually run it. Let's run it but strictly catch errors.
                    db.execSQL(userQuery);
                    showSuccess();
                } else {
                    // SELECT queries
                    Cursor cursor = db.rawQuery(userQuery, null);
                    if (cursor != null) {
                        showSuccess();
                        cursor.close();
                    }
                }
            } catch (Exception e) {
                tvResult.setTextColor(Color.RED);
                tvResult.setText("❌ Error: " + e.getMessage() + "\nTry matching: " + q.answer);
            }
        }
    }

    private void showSuccess() {
        tvResult.setTextColor(Color.parseColor("#04AA6D"));
        tvResult.setText("✅ Correct!");

        new android.os.Handler().postDelayed(() -> {
            currentQuestionIndex++;
            showQuestion();
        }, 1500);
    }
}