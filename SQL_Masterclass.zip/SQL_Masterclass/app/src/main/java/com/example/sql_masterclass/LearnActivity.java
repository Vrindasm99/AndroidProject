package com.example.sql_masterclass;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

public class LearnActivity extends AppCompatActivity {

    String[] topics = {"SELECT", "WHERE", "JOIN", "INSERT", "UPDATE", "DELETE"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learn); // Make sure you have a basic list layout here

        ListView listView = findViewById(R.id.listView); // Ensure your activity_learn.xml has a ListView with this ID

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, topics);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedTopic = topics[position];
            Intent intent = new Intent(LearnActivity.this, LearnDetailActivity.class);
            intent.putExtra("TOPIC_NAME", selectedTopic);
            startActivity(intent);
        });
    }
}